class Graph(object):
	"""docstring for Graph"""
	def __init__(self, arg):
		super(Graph, self).__init__()
		self.arg = arg
		